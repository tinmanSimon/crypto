api_key = "organizations/23343593-33bb-4a0d-ba74-7d2e1ecc06bf/apiKeys/c81000a9-fa10-46a2-abd2-f45a2b93216c"
api_secret = "-----BEGIN EC PRIVATE KEY-----\nMHcCAQEEIN0NlIS4BzkQgKpTP1nvoF3uehNdRkcS8pCY97qGcAy6oAoGCCqGSM49\nAwEHoUQDQgAEGqT7l8pQizqGxD931JPQy+ZRELNXBzm4ivzxGtmZXgYOPLlFnGMZ\nEqjbMeSBstuDfs7TZogU4tEE0ngrCLzX2w==\n-----END EC PRIVATE KEY-----\n"

# api_key = "organizations/23343593-33bb-4a0d-ba74-7d2e1ecc06bf/apiKeys/287e489d-010a-4803-80d3-34cd7efb24d7"
# api_secret = "-----BEGIN EC PRIVATE KEY-----\nMHcCAQEEIDgMZG5dNS5CxYCJgQ7xSBaTv6qQhIeV46Ju2BfKoaQ+oAoGCCqGSM49\nAwEHoUQDQgAE1wZ7BRqBifOHi7DGFUdizWa6CIiwSOXAmTDBZQVpyUTUYTltWc/O\n3cjcMVZ/P/mKqQCRDeLytT6YyHdHMNNEGg==\n-----END EC PRIVATE KEY-----\n"


# api_key = "organizations/23343593-33bb-4a0d-ba74-7d2e1ecc06bf/apiKeys/501cf2c7-caef-4e91-a412-0ed382b4e2ad"
# api_secret = "-----BEGIN EC PRIVATE KEY-----\nMHcCAQEEIFTFiWyNcE6ycD7spuVRMGoZVCFfXl8Wo8BgI4zhGLJBoAoGCCqGSM49\nAwEHoUQDQgAEQsqvCQDRbt9UmIS27FuvD5LrOp2pfwqAysiVMtq0S5RgMt+2KXXT\nUrbdT2PTsmDCdrxFD0xo/p4bC2zmDemoqQ==\n-----END EC PRIVATE KEY-----\n"

mongo_uid = "wudisas"
mongo_pwd = "WktJp1SUym6kR3Ov"
